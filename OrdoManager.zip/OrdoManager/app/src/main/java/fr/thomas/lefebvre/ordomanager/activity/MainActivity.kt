package fr.thomas.lefebvre.ordomanager.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import fr.thomas.lefebvre.ordomanager.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startListOrdoActivity()
        startNewOrdoActivity()
    }

    fun startListOrdoActivity(){
        bt_liste_ordo.setOnClickListener(View.OnClickListener {
            var listOrdoIntent=Intent(this,ListOrdoActivity::class.java)
            startActivity(listOrdoIntent)
        })
    }

    fun startNewOrdoActivity(){
        bt_new_ordo.setOnClickListener(View.OnClickListener {
            var newOrdoIntent=Intent(this,NewOrdoActivity::class.java)
            startActivity(newOrdoIntent)
        })
    }
}
